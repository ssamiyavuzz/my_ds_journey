from addition import add

print(add(5, 3))